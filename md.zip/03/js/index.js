$(document).ready(function(){
   $("#goTop").click(function(){
      $("html,body").animate({scrollTop:0}, 1000);
   })
})

$(window).scroll(function(){
      if($(this).scrollTop()>350){
         $("#goTop").fadeIn(1000);
      }else{
         $("#goTop").fadeOut();
      }
 })
  
$(document).ready(function(){
  $("#my-btn").click(function(){
     $(".read-more").slideToggle()
  });
});

//$(document).ready(function(){
  // $("#my-btn").click(function(){
    //  alert("This item is not add,")
  // })
//})